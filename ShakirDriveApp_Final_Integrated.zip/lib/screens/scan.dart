import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../utils/theme.dart';
import '../services/user_profile_service.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final _profile = UserProfileService();
  String? result;
  bool torch = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.brown,
      appBar: AppBar(
        backgroundColor: AppColors.brown,
        title: const Text("Scanner la carte prépayée"),
        actions: [
          IconButton(
            icon: Icon(torch ? Icons.flash_on : Icons.flash_off),
            onPressed: () => setState(() => torch = !torch),
          )
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 8),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: MobileScanner(
                  controller: MobileScannerController(torchEnabled: torch),
                  onDetect: (capture) {
                    final barcodes = capture.barcodes;
                    for (final b in barcodes) {
                      final raw = b.rawValue ?? '—';
                      setState(() { result = raw; });
                      // Mock activation: if QR contains digits, use them as family number
                      final digits = RegExp(r'\d+').stringMatch(raw);
                      if (digits != null) {
                        final n = int.tryParse(digits);
                        if (n != null) {
                          await _profile.setFamilyNumber(n);
                        }
                      }
                      await _profile.setActivated(true);
                      // Optionally set a welcome balance
                      await _profile.setBalance(15000); // 150€ demo
                      break;
                    }
                  },
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              result == null
                  ? "Scannez le QR Code client pour afficher le solde et l’historique."
                  : "QR détecté :\n$result\nCarte activée ✅ — Numéro enregistré et solde de démo crédité.",
              style: const TextStyle(color: AppColors.cream),
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
