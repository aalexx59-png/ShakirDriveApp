import 'package:flutter/material.dart';
import '../utils/theme.dart';

class OffersScreen extends StatelessWidget {
  const OffersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.brown,
      appBar: AppBar(
        backgroundColor: AppColors.brown,
        title: const Text("Choisissez votre carte"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Row(
                children: [
                  Expanded(child: _CardOption(
                    title: "Carte Solo",
                    subtitle: "Trop cool, tu profites à fond pour toi 😎",
                    watermark: "50€ = 70€",
                    color: Colors.white.withOpacity(0.95),
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Solo sélectionnée — Bonus +20€")));
                    },
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: _CardOption(
                    title: "Carte Family",
                    subtitle: "La famille se régale ensemble 😍",
                    watermark: "100€ = 150€",
                    color: Colors.white.withOpacity(0.95),
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Family sélectionnée — Bonus +50€")));
                    },
                  )),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                "Après 3 cartes achetées, la 4ᵉ est offerte 🎁  •  Recharge 100€ → Recevez 150€ 🤩",
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.cream),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CardOption extends StatelessWidget {
  final String title;
  final String subtitle;
  final String watermark;
  final Color color;
  final VoidCallback onTap;
  const _CardOption({required this.title, required this.subtitle, required this.watermark, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.gold.withOpacity(0.5)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Stack(
          children: [
            // Watermark
            Positioned(
              right: 8,
              bottom: 8,
              child: Text(
                watermark,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: Colors.black.withOpacity(0.08),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black)),
                const SizedBox(height: 6),
                Text(subtitle, style: const TextStyle(fontSize: 14, color: Colors.black87)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
