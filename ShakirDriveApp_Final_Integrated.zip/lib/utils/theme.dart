import 'package:flutter/material.dart';

class AppColors {
  static const brown = Color(0xFF3B2B22);
  static const brownLight = Color(0xFF6B4A36);
  static const gold = Color(0xFFC89A2B);
  static const cream = Color(0xFFF6EFE6);
}
