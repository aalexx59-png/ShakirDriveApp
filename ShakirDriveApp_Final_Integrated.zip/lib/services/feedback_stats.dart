import 'package:shared_preferences/shared_preferences.dart';

class FeedbackStats {
  static const _kSuper = 'fb_super';
  static const _kMoyen = 'fb_moyen';
  static const _kPasContent = 'fb_pascontent';

  Future<Map<String, int>> load() async {
    final sp = await SharedPreferences.getInstance();
    return {
      'super': sp.getInt(_kSuper) ?? 0,
      'moyen': sp.getInt(_kMoyen) ?? 0,
      'pascontent': sp.getInt(_kPasContent) ?? 0,
    };
  }

  Future<void> add(String choice) async {
    final sp = await SharedPreferences.getInstance();
    final key = choice == 'super'
        ? _kSuper
        : choice == 'moyen'
            ? _kMoyen
            : _kPasContent;
    final next = (sp.getInt(key) ?? 0) + 1;
    await sp.setInt(key, next);
  }

  Future<void> reset() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove(_kSuper);
    await sp.remove(_kMoyen);
    await sp.remove(_kPasContent);
  }
}
