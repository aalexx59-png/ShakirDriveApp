import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';

class UserProfileService {
  static const _kFamilyNumber = 'family_number';
  static const _kActivated = 'card_activated';
  static const _kBalance = 'wallet_balance_cents';

  Future<int> getOrCreateFamilyNumber() async {
    final sp = await SharedPreferences.getInstance();
    final existing = sp.getInt(_kFamilyNumber);
    if (existing != null) return existing;
    final rnd = Random();
    final n = 1 + rnd.nextInt(99999); // 1..99999
    await sp.setInt(_kFamilyNumber, n);
    return n;
  }

  Future<void> setFamilyNumber(int n) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt(_kFamilyNumber, n);
  }

  Future<int?> getFamilyNumber() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getInt(_kFamilyNumber);
  }

  Future<bool> isActivated() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getBool(_kActivated) ?? false;
  }

  Future<void> setActivated(bool v) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool(_kActivated, v);
  }

  Future<int> getBalance() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getInt(_kBalance) ?? 0;
  }

  Future<void> setBalance(int cents) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt(_kBalance, cents);
  }
}
