import 'package:flutter/material.dart';
import 'utils/theme.dart';
import 'screens/welcome.dart';
import 'screens/offers.dart';
import 'screens/scan.dart';
import 'screens/stats_screen.dart';
import 'screens/numerology.dart';
import 'screens/weekly_draw.dart';

void main() {
  runApp(const ShakirDriveApp());
}

class ShakirDriveApp extends StatelessWidget {
  const ShakirDriveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shakir Drive',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.brown,
        appBarTheme: const AppBarTheme(
          foregroundColor: AppColors.cream,
          titleTextStyle: TextStyle(color: AppColors.cream, fontSize: 18, fontWeight: FontWeight.w600),
        ),
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.gold, brightness: Brightness.dark),
      ),
      debugShowCheckedModeBanner: false,
      home: const WelcomeScreen(),
      routes: {
        '/offers': (_) => const OffersScreen(),
        '/scan': (_) => const ScanScreen(),
        '/stats': (_) => const StatsScreen(),
        '/numerology': (_) => const NumerologyScreen(),
        '/weeklydraw': (_) => const WeeklyDrawScreen(),
      },
    );
  }
}
