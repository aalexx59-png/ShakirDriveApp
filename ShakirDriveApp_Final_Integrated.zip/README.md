# ShakirDriveApp (Flutter)

Application **Shakir Drive** — cartes prépayées, QR code, offres (3+1, Solo/Family, bonus), feedback smileys + stats.
Pensée pour un **upload depuis smartphone** + **build Codemagic** sans PC.

## 🚀 Utilisation rapide (GitHub + Codemagic, depuis mobile)
1. Crée un dépôt GitHub vide `ShakirDriveApp`.
2. Dans le dépôt → **Add file → Upload files** → envoie **le ZIP** fourni par l’assistant.
3. Sur **Codemagic** : connecte ce dépôt → workflow `codemagic.yaml` → Android Release → **Start new build**.
4. Tu reçois l’APK par email (`aalexx59@gmail.com`).

> Astuce : `codemagic.yaml` exécute `flutter create .` automatiquement pour générer `android/` & `ios/`.

## 📂 Contenu
- `lib/` — écrans d’accueil, offres, scan QR, stats ; widget smileys ; thème couleurs.
- `assets/images/logo.png` — logo Shakir Drive (remplace par ton logo final si besoin).
- `pubspec.yaml` — dépendances (shared_preferences, mobile_scanner), assets, launcher icons.
- `codemagic.yaml` — build Android + envoi par email.

## 📸 Écrans inclus
- **Welcome** (logo, texte Famille de cœur, Drive uniquement, bouton Offres & Scanner, bloc smileys)
- **Offres** (Solo/Family avec filigranes `50€=70€` et `100€=150€`, rappel `3+1`)
- **Scan** (scanner QR, flash)
- **Stats** (barres vert/orange/rouge + total)

## 🧰 Personnalisation
- Remplace `assets/images/logo.png` par ton logo final (même nom).
- Modifie les textes promo dans `lib/screens/offers.dart`.
- Active l’icône d’app via **flutter_launcher_icons** (déjà configuré).

---

© Shakir Drive — Famille de cœur 💗
