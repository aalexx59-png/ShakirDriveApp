import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const ShakirDriveApp());
}

class ShakirDriveApp extends StatelessWidget {
  const ShakirDriveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shakir Drive',
      theme: ThemeData(
        colorSchemeSeed: Colors.blue,
        useMaterial3: true,
      ),
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  Future<void> _openEmail() async {
    final uri = Uri(
      scheme: 'mailto',
      path: 'contact@shakir-drive.com',
      queryParameters: {
        'subject': 'Demande d’information - Shakir Drive',
      },
    );
    if (!await launchUrl(uri)) {
      // ignore
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shakir Drive'),
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // ----- LOGO CENTRÉ -----
              SizedBox(
                width: 180,
                height: 180,
                child: Image.asset('assets/images/logo_shakir_drive.png'),
              ),
              const SizedBox(height: 24),
              const Text(
                'Cartes prépayées Shakir Drive',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              const Text(
                'Achetez et gérez vos cartes en toute simplicité.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _openEmail,
                child: const Text('Nous contacter'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
