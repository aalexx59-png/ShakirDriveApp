# ShakirDriveApp — Projet Flutter prêt Codemagic (Email APK)

Ce dépôt est minimal : `codemagic.yaml` lance `flutter create` pendant le build
afin de générer Android/iOS/Web, puis compile l’APK et vous l’envoie par e‑mail.

## Personnaliser

- Remplacez le logo: `assets/images/logo_shakir_drive.png` (même nom).
- Le logo apparaît **centré** sur la page d’accueil.
- Modifiez `lib/main.dart` et `pubspec.yaml` si besoin.

## Build via Codemagic

1. Connectez ce repo sur Codemagic.
2. Sélectionnez le workflow **Android Release (Email APK)**.
3. Lancez **Start new build**.

Vous recevrez l’APK par e‑mail.
