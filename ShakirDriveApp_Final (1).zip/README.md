# Shakir Drive App — Projet Flutter (Codemagic ready)

**1er Restaurant Drive Oriental au Monde — Aulnoy-lez-Valenciennes**  
Bienvenue dans la *Famille de Cœur* 💗

## Contenu
- Écran d'accueil (offres, rappel Drive uniquement)
- Profil (nom, email, anniversaire) + **carte générée n°** avec message de numérologie
- Choix carte **SOLO** (50→70) et **FAMILY** (100→150)
- Scanner **QR** (mobile_scanner)
- Sondage satisfaction (3 smileys : rouge, orange, vert)
- Codemagic: génère le dossier Android si absent puis build l'APK release

## Build via Codemagic
Le repo contient `codemagic.yaml`. Sur Codemagic, choisissez le workflow **Android Release**.  
Le script crée un shell Android si nécessaire, puis lance `flutter build apk --release`.

## Assets
Logo : `assets/images/logo_shakir_drive.png`