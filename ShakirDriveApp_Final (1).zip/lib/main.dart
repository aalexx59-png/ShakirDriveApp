import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(const ShakirDriveApp());
}

const Color kGold = Color(0xFFCB9933);
const Color kBrownDark = Color(0xFF2D1C12);
const Color kBrown = Color(0xFF3B2619);
const Color kBrownLight = Color(0xFF4E3322);

class ShakirDriveApp extends StatelessWidget {
  const ShakirDriveApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shakir Drive',
      theme: ThemeData(
        colorSchemeSeed: kGold,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF4F4F4),
        useMaterial3: true,
        textTheme: Theme.of(context).textTheme.apply(
          bodyColor: kBrown,
          displayColor: kBrown,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int counter = 0;
  String memberId = "";
  String fullName = "";
  DateTime? birthday;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      counter = prefs.getInt('counter') ?? 0;
      memberId = prefs.getString('memberId') ?? "";
      fullName = prefs.getString('fullName') ?? "";
      final bd = prefs.getString('birthday');
      if (bd != null) birthday = DateTime.tryParse(bd);
    });
  }

  Future<void> _inc() async {
    final prefs = await SharedPreferences.getInstance();
    counter++;
    await prefs.setInt('counter', counter);
    setState(() {});
  }

  String numerologyMessage(String id) {
    if (id.isEmpty) return "";
    int sum = 0;
    for (final ch in id.runes) {
      final c = String.fromCharCode(ch);
      if (RegExp(r'\d').hasMatch(c)) sum += int.parse(c);
    }
    // reduce to master numbers 11,22,33 or single digit
    while (!(sum==11 || sum==22 || sum==33) && sum>9) {
      sum = sum.toString().split('').map(int.parse).reduce((a,b)=>a+b);
    }
    switch(sum){
      case 11: return "11 – Maître nombre : intuition & inspiration ✨";
      case 22: return "22 – Maître nombre : bâtisseur & grand projet 🏗️";
      case 33: return "33 – Maître nombre : compassion & générosité 💛";
      case 1: return "1 – Leadership & nouveaux départs 🚀";
      case 2: return "2 – Coopération & harmonie 🤝";
      case 3: return "3 – Créativité & joie 🎨";
      case 4: return "4 – Stabilité & fiabilité 🧱";
      case 5: return "5 – Mouvement & chance 🍀";
      case 6: return "6 – Famille & cœur 💗";
      case 7: return "7 – Chance & sagesse 🧠🍀";
      case 8: return "8 – Réussite & abondance 💫";
      case 9: return "9 – Altruisme & accomplissement 🌟";
      default: return "";
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasProfile = fullName.isNotEmpty;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kBrownDark,
        foregroundColor: Colors.white,
        title: const Text('Shakir Drive'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Header card
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [kBrownDark, kBrown],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Image.asset('assets/images/logo_shakir_drive.png', width: 56, height: 56),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Bienvenue dans la Famille de Cœur 💗', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                          const SizedBox(height: 4),
                          Text('1er Restaurant Drive Oriental au Monde – Aulnoy-lez-Valenciennes', style: const TextStyle(color: Colors.white70)),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline, color: Colors.white70),
                      const SizedBox(width: 8),
                      const Expanded(child: Text('Rappel discret : service DR🏁VE uniquement.', style: TextStyle(color: Colors.white70))),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Profile / member
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: kGold,
                        child: const Icon(Icons.person, color: Colors.white),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(hasProfile ? 'Bonjour, $fullName' : 'Créez votre profil (nom, email, anniversaire)',
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                      FilledButton(onPressed: () async {
                        final ok = await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()));
                        if (ok == true) _loadPrefs();
                      }, child: Text(hasProfile ? 'Modifier' : 'Créer'))
                    ],
                  ),
                  if (memberId.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text("Carte générée n° $memberId", style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(numerologyMessage(memberId), style: const TextStyle(color: Colors.black54)),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Offers
          Card(
            color: const Color(0xFFFFF8E6),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Offres du moment', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  _offerTile('3 cartes achetées, la 4e OFFERTE 🎁'),
                  const SizedBox(height: 8),
                  _offerTile('Recharge SOLO: 50€ → 70€ (bonus +20€)'),
                  const SizedBox(height: 8),
                  _offerTile('Recharge FAMILY: 100€ → 150€ (bonus +50€)'),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      OutlinedButton.icon(onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const CardChoiceScreen()));
                      }, icon: const Icon(Icons.credit_card), label: const Text('Choisir carte')),
                      const SizedBox(width: 12),
                      FilledButton.icon(onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const SatisfactionScreen()));
                      }, icon: const Icon(Icons.emoji_emotions_outlined), label: const Text('Votre passage ?')),
                    ],
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // QR + history
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Scanner un QR client', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('Pour afficher l’état et l’historique (couscous poulet, merguez, brochettes) et déductions automatiques.'),
                  const SizedBox(height: 12),
                  FilledButton.icon(onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const QRScreen()));
                  }, icon: const Icon(Icons.qr_code_scanner), label: const Text('Scanner maintenant')),
                ],
              ),
            ),
          ),
          const SizedBox(height: 80),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _inc,
        label: Text('$counter'),
        icon: const Icon(Icons.add),
      ),
    );
  }
}

Widget _offerTile(String text) => Row(
  children: [
    const Icon(Icons.local_offer, color: kGold),
    const SizedBox(width: 8),
    Expanded(child: Text(text)),
  ],
);

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _birthday = TextEditingController();
  String memberId = "";

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _name.text = prefs.getString('fullName') ?? "";
    _email.text = prefs.getString('email') ?? "";
    final bd = prefs.getString('birthday');
    if (bd != null) _birthday.text = DateFormat('yyyy-MM-dd').format(DateTime.parse(bd));
    setState(() { memberId = prefs.getString('memberId') ?? ""; });
  }

  String _generateMemberId(String name, DateTime? date) {
    final ts = DateTime.now().millisecondsSinceEpoch.toString();
    final base = "${name.trim().replaceAll(' ', '').toUpperCase()}${date!=null?DateFormat('yyyyMMdd').format(date):''}$ts";
    // keep digits from hash-like
    int sum = 0;
    for (int i=0;i<base.length;i++) { sum += base.codeUnitAt(i); }
    return (sum % 999999).toString().padLeft(6,'0');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profil & Carte')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text("Vous êtes un nouveau membre de la Famille de Cœur 💗 — bienvenue !", style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Nom & Prénom'),
                validator: (v)=> v==null||v.trim().isEmpty ? "Indiquez votre nom" : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _birthday,
                readOnly: true,
                decoration: InputDecoration(
                  labelText: 'Date d’anniversaire',
                  suffixIcon: IconButton(icon: const Icon(Icons.calendar_today), onPressed: () async {
                    final now = DateTime.now();
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: DateTime(now.year-18, now.month, now.day),
                      firstDate: DateTime(1900),
                      lastDate: now,
                    );
                    if (picked != null) setState(() { _birthday.text = DateFormat('yyyy-MM-dd').format(picked); });
                  }),
                ),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: () async {
                  if(!_formKey.currentState!.validate()) return;
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString('fullName', _name.text.trim());
                  await prefs.setString('email', _email.text.trim());
                  if (_birthday.text.isNotEmpty) {
                    await prefs.setString('birthday', DateTime.parse(_birthday.text).toIso8601String());
                  }
                  // generate member id if absent
                  var id = prefs.getString('memberId') ?? "";
                  if (id.isEmpty) {
                    id = _generateMemberId(_name.text.trim(), _birthday.text.isNotEmpty ? DateTime.parse(_birthday.text) : null);
                    await prefs.setString('memberId', id);
                  }
                  if (context.mounted) Navigator.pop(context, true);
                },
                child: const Text('Enregistrer'),
              ),
              const SizedBox(height: 12),
              if (memberId.isNotEmpty) Text('Carte générée n° $memberId'),
              const SizedBox(height: 24),
              const Text('Rappel discret : service Drive uniquement. Merci 💛'),
            ],
          ),
        ),
      ),
    );
  }
}

class QRScreen extends StatelessWidget {
  const QRScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scanner QR')),
      body: Column(
        children: [
          Expanded(
            child: MobileScanner(
              onDetect: (capture) {
                final barcodes = capture.barcodes;
                if (barcodes.isNotEmpty) {
                  final value = barcodes.first.rawValue ?? "";
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("QR: $value")));
                }
              },
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(12.0),
            child: Text('Pointez la caméra vers le QR du client pour afficher son état & historique.'),
          )
        ],
      ),
    );
  }
}

class CardChoiceScreen extends StatelessWidget {
  const CardChoiceScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Choix de la carte')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _CardTile(title: "Carte SOLO", bonus: "50€ → 70€ (+20€ bonus)", desc: "Parfait pour un.e gourmand.e !"),
          SizedBox(height: 12),
          _CardTile(title: "Carte FAMILY", bonus: "100€ → 150€ (+50€ bonus)", desc: "La Famille au cœur 💗 — partagez !"),
        ],
      ),
    );
  }
}

class _CardTile extends StatelessWidget {
  final String title;
  final String bonus;
  final String desc;
  const _CardTile({required this.title, required this.bonus, required this.desc});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.05), blurRadius: 10)],
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.credit_card, size: 40, color: kGold),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 4),
                Text(bonus, style: const TextStyle(color: kBrownLight)),
                const SizedBox(height: 8),
                Text(desc),
                const SizedBox(height: 8),
                Row(
                  children: [
                    OutlinedButton(onPressed: (){}, child: const Text('Découvrir')),
                    const SizedBox(width: 8),
                    FilledButton(onPressed: (){}, child: const Text('Recharger au guichet')),
                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SatisfactionScreen extends StatefulWidget {
  const SatisfactionScreen({super.key});
  @override
  State<SatisfactionScreen> createState() => _SatisfactionScreenState();
}

class _SatisfactionScreenState extends State<SatisfactionScreen> {
  int? mood; // 0 bad, 1 ok, 2 great
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Votre passage ?')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Text('Dites-nous tout 😍', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _smiley(0, 'Peut mieux faire'),
                _smiley(1, 'Sympa'),
                _smiley(2, 'Super génial !'),
              ],
            ),
            const Spacer(),
            FilledButton(onPressed: mood==null?null:(){
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Merci pour votre retour 💛")));
              Navigator.pop(context);
            }, child: const Text('Envoyer')),
          ],
        ),
      ),
    );
  }

  Widget _smiley(int value, String caption) {
    final selected = mood == value;
    final icons = [Icons.sentiment_very_dissatisfied, Icons.sentiment_neutral, Icons.sentiment_very_satisfied];
    final colors = [Colors.red, Colors.orange, Colors.green];
    return GestureDetector(
      onTap: ()=> setState(()=> mood = value),
      child: Column(
        children: [
          CircleAvatar(
            radius: selected ? 40 : 36,
            backgroundColor: colors[value].withOpacity(.15),
            child: Icon(icons[value], size: selected? 44:38, color: colors[value]),
          ),
          const SizedBox(height: 8),
          Text(caption),
        ],
      ),
    );
  }
}