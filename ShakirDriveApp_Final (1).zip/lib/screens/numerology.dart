import 'package:flutter/material.dart';
import '../utils/theme.dart';
import '../services/user_profile_service.dart';

class NumerologyScreen extends StatefulWidget {
  const NumerologyScreen({super.key});

  @override
  State<NumerologyScreen> createState() => _NumerologyScreenState();
}

class _NumerologyScreenState extends State<NumerologyScreen> {
  final _profile = UserProfileService();
  int? familyNumber;
  String message = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  int _digitSum(int n) {
    var s = 0;
    while (n > 0) { s += n % 10; n ~/= 10; }
    return s;
  }

  String _magicMsg(int n) {
    final sum = _digitSum(n);
    if (n == 11) return "Whaouu ✨ Numéro 11 — Maître Nombre ! Énergie forte et inspirante.";
    if (n == 33) return "Magique 💛 Numéro 33 — (3+3=6) harmonie, partage et amour.";
    if (sum == 7) return "Chance 🍀 (somme des chiffres = 7) — la chance arrive bientôt !";
    if (n == 7) return "Mystique 🔮 Numéro 7 — intuition et profondeur.";
    return "Super numéro ⭐ (somme = $sum) — la magie opère avec Shakir Drive !";
  }

  Future<void> _load() async {
    final n = await _profile.getOrCreateFamilyNumber();
    setState(() {
      familyNumber = n;
      message = _magicMsg(n);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.brown,
      appBar: AppBar(backgroundColor: AppColors.brown, title: const Text('Numérologie magique')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 8),
            const Text("Votre numéro de Famille de cœur", style: TextStyle(color: AppColors.cream, fontSize: 16)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 24),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.gold.withOpacity(0.6)),
              ),
              child: Text(
                familyNumber == null ? "…" : "#${familyNumber!}",
                style: const TextStyle(color: AppColors.gold, fontSize: 32, fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.cream, fontSize: 15, height: 1.3),
            ),
            const Spacer(),
            const Text("Vivez cette expérience, Avec nous la Famille 💗", style: TextStyle(color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}
