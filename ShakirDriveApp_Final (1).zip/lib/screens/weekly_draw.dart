import 'package:flutter/material.dart';
import '../utils/theme.dart';
import '../services/user_profile_service.dart';

class WeeklyDrawScreen extends StatefulWidget {
  const WeeklyDrawScreen({super.key});

  @override
  State<WeeklyDrawScreen> createState() => _WeeklyDrawScreenState();
}

class _WeeklyDrawScreenState extends State<WeeklyDrawScreen> {
  int? winner;
  int? myNumber;
  bool amIWinner = false;

  @override
  void initState() {
    super.initState();
    _compute();
  }

  int _weekNumber(DateTime dt) {
    // Simple ISO-ish week calc
    final first = DateTime(dt.year, 1, 1);
    final days = dt.difference(first).inDays + first.weekday;
    return (days / 7).floor() + 1;
  }

  Future<void> _compute() async {
    final profile = UserProfileService();
    myNumber = await profile.getOrCreateFamilyNumber();
    final now = DateTime.now();
    final week = _weekNumber(now);
    // Deterministic pseudo-random winner per week/year
    final seed = now.year * 100 + week;
    final pseudo = (seed * 9301 + 49297) % 233280; // LCG
    winner = 1 + (pseudo % 99999);
    setState(() {
      amIWinner = (winner == myNumber);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.brown,
      appBar: AppBar(backgroundColor: AppColors.brown, title: const Text('Tirage hebdomadaire')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 8),
            const Text("Cette semaine, le gagnant est :", style: TextStyle(color: AppColors.cream)),
            const SizedBox(height: 8),
            Text(
              winner == null ? "…" : "Numéro ${winner!}",
              style: const TextStyle(color: AppColors.gold, fontSize: 28, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            Text(
              amIWinner
                  ? "🥳 Bravo ! Vous gagnez un repas Drive de 30€"
                  : "Rendez-vous la semaine prochaine, Famille de cœur 😍",
              style: const TextStyle(color: AppColors.cream, fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            const Text("Affichage festif (confettis) prévu en V2 🎉", style: TextStyle(color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}
