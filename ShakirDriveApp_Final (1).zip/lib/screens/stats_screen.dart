import 'package:flutter/material.dart';
import '../services/feedback_stats.dart';
import '../utils/theme.dart';

class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});

  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  final _stats = FeedbackStats();
  int superN = 0, moyenN = 0, pasN = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final m = await _stats.load();
    setState(() {
      superN = m['super']!;
      moyenN = m['moyen']!;
      pasN = m['pascontent']!;
      loading = false;
    });
  }

  int get total => superN + moyenN + pasN;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.brown,
      appBar: AppBar(
        backgroundColor: AppColors.brown,
        title: const Text('Statistiques des avis'),
        actions: [
          IconButton(
            tooltip: 'Réinitialiser',
            onPressed: () async {
              await _stats.reset();
              await _load();
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Compteurs remis à zéro')),
              );
            },
            icon: const Icon(Icons.refresh),
          )
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _TotalCard(total: total),
                  const SizedBox(height: 16),
                  Expanded(
                    child: _Bars(superN: superN, moyenN: moyenN, pasN: pasN),
                  ),
                  const SizedBox(height: 8),
                  const _Legend(),
                  const SizedBox(height: 16),
                  const Text(
                    'Merci pour vos retours 💗 Famille de cœur',
                    style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
    );
  }
}

class _TotalCard extends StatelessWidget {
  final int total;
  const _TotalCard({required this.total});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Avis collectés', style: TextStyle(color: AppColors.cream, fontSize: 16)),
          Text('$total', style: const TextStyle(color: AppColors.gold, fontSize: 22, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _Bars extends StatelessWidget {
  final int superN, moyenN, pasN;
  const _Bars({required this.superN, required this.moyenN, required this.pasN});

  @override
  Widget build(BuildContext context) {
    final maxVal = [superN, moyenN, pasN].fold<int>(0, (p, e) => e > p ? e : p);
    final h = MediaQuery.of(context).size.height * 0.32;
    double barH(int v) => maxVal == 0 ? 4 : (v / maxVal) * (h - 24);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _Bar(label: '😀', value: superN, height: barH(superN), color: Colors.green),
        _Bar(label: '😐', value: moyenN, height: barH(moyenN), color: Colors.orange),
        _Bar(label: '😕', value: pasN,   height: barH(pasN),   color: Colors.red),
      ],
    );
  }
}

class _Bar extends StatelessWidget {
  final String label;
  final int value;
  final double height;
  final Color color;

  const _Bar({required this.label, required this.value, required this.height, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          width: 54,
          height: height,
          decoration: BoxDecoration(
            color: color.withOpacity(0.9),
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(fontSize: 20, color: AppColors.cream)),
        const SizedBox(height: 2),
        Text('$value', style: const TextStyle(color: Colors.white70)),
      ],
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend();

  @override
  Widget build(BuildContext context) {
    Widget dot(Color c, String t) => Row(
      children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(t, style: const TextStyle(color: AppColors.cream)),
      ],
    );

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        dot(Colors.green, 'Super génial'),
        dot(Colors.orange, 'Moyen bof'),
        dot(Colors.red, 'Pas content'),
      ],
    );
  }
}
