import 'package:flutter/material.dart';
import '../utils/theme.dart';
import 'offers.dart';
import 'scan.dart';
import 'numerology.dart';
import 'weekly_draw.dart';
import 'stats_screen.dart';
import '../widgets/smile_feedback.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.brown,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 12),
                // Logo
                Image.asset('assets/images/logo.png', width: 120, errorBuilder: (_, __, ___) => const Icon(Icons.ramen_dining, size: 80, color: AppColors.gold)),
                const SizedBox(height: 16),
                const Text(
                  "Bienvenue dans la Famille de cœur 💗",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.cream, fontSize: 22, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                const Text(
                  "Vivez cette expérience, Avec nous la Famille.
Offres valables uniquement pour le Drive 🚗",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 24),
                // Buttons
                Wrap(
                  alignment: WrapAlignment.center, spacing: 12, runSpacing: 12,
                  children: [
                    ElevatedButton.icon(
                      icon: const Icon(Icons.local_offer),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.gold, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OffersScreen())),
                      label: const Text("Découvrir les offres"),
                    ),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.qr_code_scanner, color: AppColors.cream),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.cream),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ScanScreen())),
                      label: const Text("Scanner une carte", style: TextStyle(color: AppColors.cream)),
                    ),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.auto_fix_high),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NumerologyScreen())),
                      label: const Text("Numérologie"),
                    ),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.celebration, color: AppColors.cream),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.cream),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WeeklyDrawScreen())),
                      label: const Text("Tirage 30€", style: TextStyle(color: AppColors.cream)),
                    ),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.bar_chart, color: AppColors.cream),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.cream),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StatsScreen())),
                      label: const Text("Stats avis", style: TextStyle(color: AppColors.cream)),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // Feedback block
                const SmileFeedback(),
                const Spacer(),
                const Text("1er Restaurant Drive Oriental au Monde !!!", style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
