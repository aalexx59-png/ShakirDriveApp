import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/feedback_stats.dart';
import '../utils/theme.dart';

class SmileFeedback extends StatefulWidget {
  final void Function(String choice)? onSubmit;
  const SmileFeedback({super.key, this.onSubmit});

  @override
  State<SmileFeedback> createState() => _SmileFeedbackState();
}

class _SmileFeedbackState extends State<SmileFeedback> {
  String? _selected;
  final _stats = FeedbackStats();

  void _select(String value) async {
    HapticFeedback.selectionClick();
    setState(() => _selected = value);
    await _stats.add(value);
    widget.onSubmit?.call(value);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.brown.withOpacity(0.85),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text(
            "Comment s’est passé votre passage au Drive ?",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.cream,
              fontSize: 18,
              fontWeight: FontWeight.w600,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 14,
            runSpacing: 14,
            alignment: WrapAlignment.center,
            children: [
              _SmileCard(
                emoji: "😀",
                label: "Super génial",
                color: Colors.green,
                selected: _selected == "super",
                onTap: () => _select("super"),
              ),
              _SmileCard(
                emoji: "😐",
                label: "Moyen bof",
                color: Colors.orange,
                selected: _selected == "moyen",
                onTap: () => _select("moyen"),
              ),
              _SmileCard(
                emoji: "😕",
                label: "Pas content",
                color: Colors.red,
                selected: _selected == "pascontent",
                onTap: () => _select("pascontent"),
              ),
            ],
          ),
          if (_selected != null) ...[
            const SizedBox(height: 12),
            Text(
              _selected == "super"
                  ? "Merci ! Vous êtes au top 🥰"
                  : _selected == "moyen"
                      ? "Merci pour le retour, on va faire mieux !"
                      : "Oups, désolé 😔 On s’améliore dès maintenant.",
              style: const TextStyle(color: AppColors.gold, fontSize: 14, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}

class _SmileCard extends StatelessWidget {
  final String emoji;
  final String label;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  const _SmileCard({
    required this.emoji,
    required this.label,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      duration: const Duration(milliseconds: 140),
      scale: selected ? 1.05 : 1.0,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          width: 120,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.95),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? color : Colors.black12,
              width: selected ? 2.5 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.12),
                blurRadius: 10,
                offset: const Offset(0, 4),
              )
            ],
          ),
          child: Column(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 42)),
              const SizedBox(height: 8),
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: color,
                  height: 1.1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
